using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnahtarKapiKodu : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject kapi;
    public Sprite acikkapi;
    public void KapiyiAc()
    {
        kapi.GetComponent<SpriteRenderer>().sprite = acikkapi;
        kapi.GetComponent<BoxCollider2D>().enabled = true;
    }
}
