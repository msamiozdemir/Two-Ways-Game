using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerManager : MonoBehaviour
{
    public float health;

    bool dead = false;

    public Slider slider;

   


    // Start is called before the first frame update
    void Start()
    {
        slider.maxValue = health;
        slider.value = health;
    }

    // Update is called once per frame
    void Update()
    {
       

    }
    
    public void  GetDamage(float damage)
    {
        if ((health - damage) >= 0)
        {
            health -= damage;
        }
        else
        {
            health = 0;
        }
        slider.value = health;
        AmIdead();

    }
    void AmIdead()
    {
        if(health <= 0)
        {
            SceneManager.LoadScene(8);
            dead = true;
            
           

        }
    }
}
